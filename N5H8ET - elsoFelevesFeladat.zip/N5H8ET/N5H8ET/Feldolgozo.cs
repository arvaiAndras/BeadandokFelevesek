﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N5H8ET
{
    class Feldolgozo
    {
        private string[] Adatok;
        private FajlKezelo fajlKezelo;
        private string[] Kimenet;

        public Feldolgozo()
        {
            fajlKezelo = new FajlKezelo();
            Adatok = fajlKezelo.Beolvas();
            Kimenet = Megoldo(Adatok, "").Split(',');
            fajlKezelo.Kiir(KimenetSzures(Kimenet),Adatok.Length);
        }
        private bool EgyszinuE(string[] tomb)
        {
            string egybe = "";
            for (int i = 0; i < tomb.Length; i++)
            {
                for (int j = 0; j < tomb.Length; j++)
                {
                    egybe += tomb[i][j];
                }
            }
            return Elofordulas(egybe, egybe[0]) == egybe.Length;
        }

        private int Elofordulas(string str, char a)
        {
            int elof = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == a) elof++;
            }
            return elof;
        }

        private string[] KimenetSzures(string[] szuretlen)
        {
            int elemszam = 0;
            for (int i = 0; i < szuretlen.Length; i++)
            {
                if (szuretlen[i] != "") elemszam++;
            }
            string[] visszateres = new string[elemszam];
            int index = 0;
            for (int i = 0; i < szuretlen.Length; i++)
            {
                if (szuretlen[i] != "")
                {
                    visszateres[index] = szuretlen[i];
                    index++;
                }
            }
            return visszateres;
        }

        private string Megoldo(string[] tomb, string tag)
        {
            if (EgyszinuE(tomb)) return
                    tag + "0" + tomb[0][0];
            else
            {
                string elso = Megoldo(ReszTomb(tomb, 1), tag + "1") + ",";
                string masodik = Megoldo(ReszTomb(tomb, 2), tag + "2") + ",";
                string harmadik = Megoldo(ReszTomb(tomb, 3), tag + "3") + ",";
                string negyedik = Megoldo(ReszTomb(tomb, 4), tag + "4") + ",";
                return elso + masodik + harmadik + negyedik;
            }
        }

        private string[] ReszTomb(string[] tomb, int szektor)
        {
            int dimenzio = tomb.Length / 2;
            string[] visszateres = new string[dimenzio];
            int sorIndex = 0;
            if (szektor == 1)
            {
                for (int i = 0; i < dimenzio; i++)
                {
                    string sor = "";
                    for (int j = 0; j < dimenzio; j++)
                    {
                        sor += tomb[i][j];
                    }
                    visszateres[sorIndex] = sor;
                    sorIndex++;
                }
            }
            else if (szektor == 2)
            {
                for (int i = 0; i < dimenzio; i++)
                {
                    string sor = "";
                    for (int j = dimenzio; j < tomb.Length; j++)
                    {
                        sor += tomb[i][j];
                    }
                    visszateres[sorIndex] = sor;
                    sorIndex++;
                }
            }
            else if (szektor == 3)
            {
                for (int i = dimenzio; i < tomb.Length; i++)
                {
                    string sor = "";
                    for (int j = 0; j < dimenzio; j++)
                    {
                        sor += tomb[i][j];
                    }
                    visszateres[sorIndex] = sor;
                    sorIndex++;
                }
            }
            else
            {
                for (int i = dimenzio; i < tomb.Length; i++)
                {
                    string sor = "";
                    for (int j = dimenzio; j < tomb.Length; j++)
                    {
                        sor += tomb[i][j];
                    }
                    visszateres[sorIndex] = sor;
                    sorIndex++;
                }
            }
            return visszateres;
        }

    }
}

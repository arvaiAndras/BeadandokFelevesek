﻿using System;
using System.IO;
using System.Text;

namespace N5H8ET
{
    class Program
    {
        static void Main(string[] args)
        {
            new Feldolgozo();
        }
    }
}

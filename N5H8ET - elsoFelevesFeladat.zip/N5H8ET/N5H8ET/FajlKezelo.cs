﻿using System;
using System.IO;

namespace N5H8ET
{
    internal class FajlKezelo
    {
        public string[] Beolvas()
        {
            string[] nyersAdat = File.ReadAllLines("kodol.be.txt");
            string[] adatok = new string[nyersAdat.Length - 1];
            for (int i = 0; i < adatok.Length; i++)
            {
                adatok[i] = nyersAdat[i + 1];
            }
            Console.WriteLine("A fájlt Beolvasva!");
            return adatok;
        }

        public void Kiir(string[] adatok, int N)
        {
            StreamWriter sr = new StreamWriter("kodol.ki.txt");
            sr.WriteLine($"{N} {adatok.Length}");
            for (int i = 0; i < adatok.Length; i++)
            {
                sr.WriteLine(adatok[i]);
            }
            sr.Close();
            Console.WriteLine("A Fájl kiírva!");
        }
    }
}
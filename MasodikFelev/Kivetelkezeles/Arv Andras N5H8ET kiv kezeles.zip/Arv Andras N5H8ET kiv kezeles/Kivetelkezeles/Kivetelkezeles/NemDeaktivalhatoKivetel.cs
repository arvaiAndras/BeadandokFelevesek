﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kivetelkezeles
{
    class NemDeaktivalhatoKivetel : System.Exception
    {
        public NemDeaktivalhatoKivetel(string hiba, Exception ndk)
            :base(hiba,ndk)
        {

        }
    }
}

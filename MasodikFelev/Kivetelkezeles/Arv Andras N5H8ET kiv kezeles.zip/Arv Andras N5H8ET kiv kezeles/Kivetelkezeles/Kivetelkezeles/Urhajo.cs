﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Net.Security;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Kivetelkezeles
{
    class Urhajo
    {
        string  nev { get; }
        int uresTomeg { get;}
        int aktualisTeljesitmeny;
        public int AktualisTeljesitmeny { get { return aktualisTeljesitmeny; } }
        UrhajoKategoria kategoria { get; }
        IKomponens[] komponensek;

        public Urhajo(string nev, int uresTomeg, UrhajoKategoria kategoria)
        {
            this.nev = nev;
            this.uresTomeg = uresTomeg;
            switch (kategoria)
            {
                case UrhajoKategoria.Allomas:
                    komponensek = new IKomponens[20];
                    break;
                case UrhajoKategoria.Teher:
                    komponensek = new IKomponens[8];
                    break;
                case UrhajoKategoria.Rombolo:
                    komponensek = new IKomponens[8];
                    break;
                case UrhajoKategoria.Fregatt:
                    komponensek = new IKomponens[6];
                    break;
                case UrhajoKategoria.Korvett:
                    komponensek = new IKomponens[4];
                    break;
                default:
                    komponensek = new IKomponens[2];
                    break;
            }
            if (uresTomeg <= 0)
                throw new ArgumentOutOfRangeException($"{nameof(uresTomeg)}");
            if (nev == null)
                throw new ArgumentNullException($"{nameof(nev)}");
            Console.WriteLine($"{nev} létrehozva!");
        }
        public void KomponensFelszerel(IKomponens komponens)
        {
            int i = 0;
            while (komponensek.Length > i && komponensek[i] != null)
            {
                ++i;
            }
            if (i < komponensek.Length)
            {
                komponensek[i] = komponens;
                Console.WriteLine($"[Hozzaadas] {komponens.GetType().Name} hozzaadva a(z) {nev} hajohoz");
            }
            else
                throw new KomponensNemFerElKivetel($"A komponens nem fér el!", komponens);

        }
        public void KomponensLeszerel(int ind)
        {
            if (komponensek[ind] == null)
                throw new KomponensNemTalalhatoKivetel($"A törölni kívánt komponens nem található!");
            else
            {
                komponensek[ind] = null;
                Console.WriteLine($"[Leszereles] A(z) {ind} indexu komponens leszerelve a(z) {nev} hajorol");
            }
        }

        public void Padlogaz()
        {
            int seged = aktualisTeljesitmeny;
            int seged2;
            for (int i = 0; i < komponensek.Length; i++)
            {
                if (komponensek[i] != null && komponensek[i] is Hajtomu && komponensek[i].Allapot.Equals(false))
                {
                    komponensek[i].Aktival();
                    aktualisTeljesitmeny -= komponensek[i].Teljesitmeny;
                }
                if (aktualisTeljesitmeny < 0)
                {
                    seged2 = aktualisTeljesitmeny;
                    aktualisTeljesitmeny = seged;

                    for (int j = 0; j <= i; j++)
                    {
                        if (komponensek[j] != null && komponensek[j] is Hajtomu && komponensek[j].Allapot.Equals(true))
                        {
                            komponensek[j].Deaktival();
                        }
                    }
                    throw new NincsElegEnergiaKivetel(0 - seged2);
                }

            }
            Console.WriteLine($"[PADLÓGÁZ] A(z) {nev} padlógázon megy!");
        }

        public void Beindit()
        {
            for (int i = 0; i < komponensek.Length; i++)
            {
                if (komponensek[i] != null && komponensek[i] is Reaktor)
                {
                    try
                    {
                        komponensek[i].Aktival();
                        aktualisTeljesitmeny -= komponensek[i].Teljesitmeny;
                    }
                    catch (InvalidOperationException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (NotSupportedException)
                    {
                        KomponensLeszerel(i);
                    }
                }
            }
            Console.WriteLine($"[BEINDITÁS] A(z) {nev} urhajo beindítva!");
        }

        public void Leallit()
        {
            for (int i = 0; i < komponensek.Length; i++)
            {
                if (komponensek[i] != null)
                {
                    try
                    {
                        komponensek[i].Deaktival();
                    }
                    catch (Exception e)
                    {

                        throw new NemDeaktivalhatoKivetel($"Egy komponens nem deaktiválható!", e);
                    }
                }
            }
            Console.WriteLine($"[LEÁLLÍTÁS] A(z) {nev} urhajó leállítva!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kivetelkezeles
{
    class Reaktor : IKomponens
    {
        private int teljesitmeny;
        public Reaktor(int teljesitmeny)
        {
            this.teljesitmeny = teljesitmeny;
        }

        public int Teljesitmeny { get; set; }
        public bool Allapot { get; set; }

        public void Aktival()
        {
            if (Allapot.Equals(true))
                throw new InvalidOperationException("[HIBA] A reaktor már fut!");
            else if (teljesitmeny.Equals(0))
                throw new NotSupportedException("[HIBA] A reaktor nem lehet 0 MW teljesítményű!");
            else
            {
                Teljesitmeny = -teljesitmeny;
                Allapot = true;
            }
        }

        public void Deaktival()
        {
            if (Allapot.Equals(false))
                throw new InvalidOperationException("[HIBA] A reaktor már nem fut!");
            else
            {
                Teljesitmeny = 0;
                Allapot = false;
            }
        }
    }
}

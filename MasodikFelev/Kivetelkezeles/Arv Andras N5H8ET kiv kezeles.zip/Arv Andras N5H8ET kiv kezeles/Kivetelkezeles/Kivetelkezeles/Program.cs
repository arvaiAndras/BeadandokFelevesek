﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kivetelkezeles
{
    enum UrhajoKategoria
    {
        Yacht,
        Korvett,
        Fregatt,
        Rombolo,
        Teher,
        Allomas
    }
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }

            Urhajo starDestroyer = new Urhajo("Star Destroyer #5530", 63, UrhajoKategoria.Rombolo);
            Urhajo serenity = new Urhajo("Serenity", 50, UrhajoKategoria.Yacht);
            Urhajo oldBessie = new Urhajo("Old Bessie", 434, UrhajoKategoria.Allomas);
            Urhajo razorBack = new Urhajo("Razor Back", 244, UrhajoKategoria.Allomas);

            Hajtomu oneHajtomu = new Hajtomu(1100);
            Hajtomu twoHajtomu = new Hajtomu(1100);
            Hajtomu threeHajtomu = new Hajtomu(1100);
            Hajtomu fourHajtomu = new Hajtomu(1100);
            Hajtomu fiveHajtomu = new Hajtomu(1100);
            Hajtomu sixHajtomu = new Hajtomu(1100);
            Hajtomu sevenHajtomu = new Hajtomu(1100);
            Hajtomu eightHajtomu = new Hajtomu(1100);

            Reaktor oneReaktor = new Reaktor(80000);

            #region KivetelKezeles
            #region NevError
            try
            {
                Urhajo nevError = new Urhajo(null, 65, UrhajoKategoria.Allomas);
            }
            catch (ArgumentNullException e) //nev==null
            {
                Console.WriteLine("[KIVÉTEL] " +e.Message);
            }
            #endregion
            #region TomegError
            try
            {
                Urhajo tomegError = new Urhajo("tomegError", 0, UrhajoKategoria.Allomas);
            }
            catch (ArgumentOutOfRangeException e) //uresTomeg <= 0
            {
                Console.WriteLine("[KIVÉTEL] " + e.Message);
            }
            #endregion
            #region KomponensNemFerEl
            try
            {
                serenity.KomponensFelszerel(oneHajtomu);
                serenity.KomponensFelszerel(twoHajtomu);

                oldBessie.KomponensFelszerel(oneHajtomu);

                razorBack.KomponensFelszerel(oneHajtomu);
                razorBack.KomponensFelszerel(oneReaktor); //reaktor

                starDestroyer.KomponensFelszerel(oneHajtomu);
                starDestroyer.KomponensFelszerel(twoHajtomu);
                starDestroyer.KomponensFelszerel(threeHajtomu);
                starDestroyer.KomponensFelszerel(fourHajtomu);
                starDestroyer.KomponensFelszerel(fiveHajtomu);
                starDestroyer.KomponensFelszerel(sixHajtomu);
                starDestroyer.KomponensFelszerel(sevenHajtomu);
                starDestroyer.KomponensFelszerel(oneReaktor); //reaktor

                serenity.KomponensFelszerel(threeHajtomu); //plusz

            }
            catch (KomponensNemFerElKivetel e)
            {
                Console.WriteLine("[KIVÉTEL] " + e.Message);
            }
            #endregion
            #region KomponensNemTalalhato
            try
            {
                starDestroyer.KomponensLeszerel(0);

                starDestroyer.KomponensLeszerel(0); //nincs
            }
            catch (KomponensNemTalalhatoKivetel e)
            {
                Console.WriteLine("[KIVÉTEL] " + e.Message);
            }
            #endregion
            #region NincsEnergiaKivitel
            try
            {
                starDestroyer.Padlogaz();
            }
            catch (NincsElegEnergiaKivetel e)
            {
                Console.WriteLine("[KIVÉTEL] " + e.Message);
            }
            #endregion
            #region BE/KI Kapcs && Leszereleses
            try
            {
                starDestroyer.Beindit();
                starDestroyer.Beindit();
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (NotSupportedException e)
            {
                Console.WriteLine(e.Message);
            }
            #endregion;
            
            starDestroyer.Padlogaz();
            starDestroyer.Leallit();
            ;
            try
            {
                razorBack.Leallit();
                ;
            }
            catch (NemDeaktivalhatoKivetel e)
            {

                 Console.WriteLine("[KIVETEL] " + e.Message);
            }





            ;
            #endregion
        }
    }
}

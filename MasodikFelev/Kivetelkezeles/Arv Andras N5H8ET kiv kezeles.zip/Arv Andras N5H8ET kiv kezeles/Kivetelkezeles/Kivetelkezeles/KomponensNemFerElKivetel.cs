﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kivetelkezeles
{
    class KomponensNemFerElKivetel : System.Exception
    {
        IKomponens komponens { get; }
        public KomponensNemFerElKivetel(string hiba, IKomponens komponens)
            :base(hiba)
        {
            this.komponens = komponens;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    class BejaroTippelo : GepiJatekos
    {
        int aktualis;
        public void JatekIndul(int alsoHatar, int felsoHatar)
        {
            base.JatekIndul(alsoHatar,felsoHatar);
            base.alsoHatar = aktualis;
        }
        public override int KovetkezoTipp()
        {
            return aktualis++;
        }
    }
}

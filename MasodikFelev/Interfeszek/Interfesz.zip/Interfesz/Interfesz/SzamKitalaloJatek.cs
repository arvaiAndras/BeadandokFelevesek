﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    class SzamKitalaloJatek
    {
        Random rnd;
        const int MAX_VERSENYZO = 5;
        ITippelo[] versenyzok = new ITippelo[MAX_VERSENYZO];
        int versenyzoN = 0;

        int alsoHatar, felsoHatar;

        int cel;
        public SzamKitalaloJatek(int alsoHatar, int felsoHatar)
        {
            this.alsoHatar = alsoHatar;
            this.felsoHatar = felsoHatar;
        }
        public void VersenyzoFelvetele(ITippelo versenyzo)
        {
            versenyzok[versenyzoN++] = versenyzo;
        }
        protected void VersenyIndul()
        {
            Console.WriteLine("VersenyIndul");
            rnd = new Random();
            cel = rnd.Next(alsoHatar, felsoHatar + 1);
            Console.WriteLine($"Cél: '{cel}'");
            for (int i = 0; i < versenyzoN; i++)
            {
                versenyzok[i].JatekIndul(alsoHatar, felsoHatar);
            }
        }
        protected bool MindenkiTippel()
        {
            Console.WriteLine("Mindenki tippel");
            bool nyert = false;
            int[] tippek = new int[versenyzoN];
            for (int i = 0; i < versenyzoN; i++)
            {
                int tipp = versenyzok[i].KovetkezoTipp();
                Console.WriteLine($"'{i + 1}'. számú versenyző : '{versenyzok[i]}' tippje: '{tipp}'");
                if (cel.Equals(tipp))
                {
                    Console.WriteLine($"'{versenyzok[i]}' ELTALÁLTA! TIPPJE: '{tipp}'");
                    versenyzok[i].Nyert();
                    nyert = true;
                    tippek[i] = tipp;
                }
                else
                {
                    tippek[i] = -1;
                    if (versenyzok[i] is IOkosTippelo)
                    {
                        if (tipp > cel)
                        {
                            (versenyzok[i] as IOkosTippelo).Kisebb();
                        }
                        else
                        {
                            (versenyzok[i] as IOkosTippelo).Nagyobb();
                        }
                    }
                }
            }
            if (nyert)
            {
                for (int i = 0; i < versenyzoN; i++)
                {
                    if (tippek[i].Equals(-1))
                    {
                        versenyzok[i].Veszitett();
                    }
                }
            }
            return nyert;
        }

        public virtual void Jatek()
        {
            VersenyIndul();
            while (!MindenkiTippel())
            {

            }
        }
        public virtual void Statisztika(int korokSzama)
        {
            for (int i = 0; i < korokSzama; i++)
            {
                Jatek();
            }
            for (int i = 0; i < versenyzoN; i++)
            {
                if (versenyzok[i] is IStatisztikaSzolgaltat)
                {
                    Console.WriteLine($"'{i}'. Játékos '{versenyzok[i]}', nyert: {(versenyzok[i] as IStatisztikaSzolgaltat).HanyszorNyert}, vesztett: {(versenyzok[i] as IStatisztikaSzolgaltat).HanyszorVesztett} ");
                }
            }
        }
    }
}

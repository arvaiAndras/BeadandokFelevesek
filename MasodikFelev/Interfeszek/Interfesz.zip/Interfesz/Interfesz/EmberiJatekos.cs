﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    class EmberiJatekos : IOkosTippelo
    {
        public void JatekIndul(int alsoHatar, int felsoHatar)
        {
            Console.WriteLine($"A játék kezdődik, '{alsoHatar}' és '{felsoHatar}' között.");
        }
        public void Kisebb()
        {
            Console.WriteLine("*Az előző tippnél kisebb a keresett szám!");
        }
        public void Nagyobb()
        {
            Console.WriteLine("*Az előző tippnél nagyobb a keresett szám!");
        }
        public int KovetkezoTipp()
        {
            Console.WriteLine("*Add meg a következő tippet!");
            return int.Parse(Console.ReadLine());
        }
        public void Nyert()
        {
            Console.WriteLine("NYERTÉL!");
        }
        public void Veszitett()
        {
            Console.WriteLine("VESZÍTETTÉL");
        }
    }
}

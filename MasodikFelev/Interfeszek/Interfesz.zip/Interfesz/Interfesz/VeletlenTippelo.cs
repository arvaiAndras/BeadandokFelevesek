﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    class VeletlenTippelo : GepiJatekos
    {
        Random rnd = new Random();
        public override int KovetkezoTipp()
        {
            return rnd.Next(base.alsoHatar, base.felsoHatar + 1);
        }
    }
}

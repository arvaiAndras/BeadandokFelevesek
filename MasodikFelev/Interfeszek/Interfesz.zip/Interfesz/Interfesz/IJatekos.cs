﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    interface IJatekos
    {
        public void Nyert();
        public void Veszitett();
    }
}

﻿using System;

namespace Interfesz
{
    class Program
    {
        static void Main(string[] args)
        {
            SzamKitalaloJatekKaszino kaszino = new SzamKitalaloJatekKaszino(1, 100, 1);

            ITippelo vt = new VeletlenTippelo();
            ITippelo bt = new BejaroTippelo();
            ITippelo lk = new LogaritmikusKereso();

            kaszino.VersenyzoFelvetele(vt);
            kaszino.VersenyzoFelvetele(bt);
            kaszino.VersenyzoFelvetele(lk);

            kaszino.Statisztika(1000);
            Console.ReadLine();
        }
    }
}

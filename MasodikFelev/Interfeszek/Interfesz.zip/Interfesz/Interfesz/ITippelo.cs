﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    interface ITippelo : IJatekos
    {
        public void JatekIndul(int alsoHatar, int felsoHatar);
        public int KovetkezoTipp();
    }
}

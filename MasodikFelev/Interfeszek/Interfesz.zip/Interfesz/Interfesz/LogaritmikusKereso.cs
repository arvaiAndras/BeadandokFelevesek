﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    class LogaritmikusKereso : GepiJatekos,IOkosTippelo
    {
        public override int KovetkezoTipp()
        {
            return (alsoHatar + felsoHatar) / 2;
        }
        public void Kisebb()
        {
            felsoHatar = ((alsoHatar + felsoHatar) / 2) - 1;
        }
        public void Nagyobb()
        {
            alsoHatar = ((alsoHatar + felsoHatar) / 2) + 1;
        }
    }
}

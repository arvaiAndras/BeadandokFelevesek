﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfesz
{
    abstract class GepiJatekos : ITippelo, IStatisztikaSzolgaltat
    {
        public int alsoHatar, felsoHatar;
        int nyertDB, veszitettDB;
        public int HanyszorNyert { get { return nyertDB; } }
        public int HanyszorVesztett { get { return veszitettDB; } }
        public void JatekIndul(int alsoHatar, int felsoHatar)
        {
            this.alsoHatar = alsoHatar;
            this.felsoHatar = felsoHatar;
        }
        public void Nyert()
        {
            nyertDB++;
        }
        public void Veszitett()
        {
            veszitettDB++;
        }
        public abstract int KovetkezoTipp();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiLancolt
{
    class NincsIlyenElemException : Exception
    {
        public NincsIlyenElemException() : base("Nincs ilyen elem a listában")
        {

        }
    }
}

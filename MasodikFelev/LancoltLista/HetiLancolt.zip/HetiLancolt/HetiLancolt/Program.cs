﻿using System;

namespace HetiLancolt
{
    class Program
    { 
        static void Main(string[] args)
        {
            LancoltLista lista = new LancoltLista();

            Szuperhos ironMan = new Szuperhos("IronMan", false, 100, 90, SzuperhosEnum.jo);
            Szuperhos spiderMan = new Szuperhos("SpiderMan", true, 80, 130,SzuperhosEnum.jo);
            Szuperhos thanos = new Szuperhos("Thanos", true, 1000, 70,SzuperhosEnum.gonosz);
            Szuperhos vision = new Szuperhos("Vision", false, 900, 120,SzuperhosEnum.jo);

            lista.ElemBeszuras(ironMan);
            lista.ElemBeszuras(spiderMan);
            lista.ElemBeszuras(thanos);
            lista.ElemBeszuras(vision);

            Szuperhos ironMan2 = new Szuperhos("IronMan", false, 100, 90, SzuperhosEnum.jo);
            Szuperhos thanos2 = new Szuperhos("Thanos", true, 1000, 70, SzuperhosEnum.gonosz);
            Szuperhos wasp = new Szuperhos("Darázs", false, 50, 90, SzuperhosEnum.gonosz);
            Szuperhos antMan = new Szuperhos("AntMan", true, 65, 80, SzuperhosEnum.jo);



            LancoltLista mutansok = lista.Szures(true);
            LancoltLista nemMutansok = lista.Szures(false);
            LancoltLista thanosnakHivjak = lista.Szures("Thanos");
            LancoltLista eroMero = lista.Szures(900);


            Console.WriteLine("Listában szereplők:");
            lista.Bejaras();
            Console.WriteLine("Mutánsok:");
            mutansok.Bejaras();
            Console.WriteLine("Nem Mutánsok");
            nemMutansok.Bejaras();
            Console.WriteLine("Thanosnak hívják");
            thanosnakHivjak.Bejaras();
            Console.WriteLine("900-as az ereje");
            eroMero.Bejaras();


            try
            {
                lista.Kereses("IronMan");
                //lista.Kereses("Batman");
                lista.Torles(ironMan);
                lista.Torles(80);
                //lista.Torles(5000);
                lista.Torles("SpiderMan");
                //lista.Torles("SpiderMan");
                lista.Torles("CatWoman");
            }
            catch (NincsIlyenElemException)
            {
                Console.WriteLine("Nincs ilyen elem a listában");
            }
            catch (NemtudTorolni)
            {
                Console.WriteLine("nem tudja törölni");
            }


            Console.ReadLine();
            ;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiLancolt
{
    class NemtudTorolni: Exception
    {
        public NemtudTorolni() : base("Nem tudja törölni ezt az elemet, mert nincs")
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiLancolt
{
    enum SzuperhosEnum
    {
        jo,
        gonosz,
        civil
    }
    class Szuperhos
    {
        public string Nev { get; set; }
        public bool Mutans { get; set; }
        public int Ero { get; set; }
        public int Gyorsasag { get; set; }
        public SzuperhosEnum Oldal { get; }
        public Szuperhos(string nev, bool mutans, int ero, int gyorsasag, SzuperhosEnum oldal)
        {
            Nev = nev;
            Mutans = mutans;
            Ero = ero;
            Gyorsasag = gyorsasag;
            Oldal = oldal;
        }
    }
}

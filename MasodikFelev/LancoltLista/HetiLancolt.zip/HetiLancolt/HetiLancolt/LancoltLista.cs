﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiLancolt
{
    class ListaElem
    {
        public Szuperhos szuperhos { get; set; }
        public ListaElem Kovetkezo { get; set; }
        public ListaElem(Szuperhos szuperhos)
        {
            this.szuperhos = szuperhos;
        }
    }

    class LancoltLista
    {
        private ListaElem fej;

        public void ElemBeszuras(Szuperhos szuperhos)
        {
            ListaElem uj = new ListaElem(szuperhos);
            uj.szuperhos.Ero = szuperhos.Ero;
            uj.szuperhos = szuperhos;
            if (fej == null)
            {
                uj.Kovetkezo = null;
                fej = uj;
            }
            else
            {
                if (fej.szuperhos.Ero > szuperhos.Ero)
                {
                    uj.Kovetkezo = fej;
                    fej = uj;
                }
                else
                {
                    ListaElem p = fej;
                    ListaElem e = null;
                    while ((p != null) && (p.szuperhos.Ero < szuperhos.Ero))
                    {
                        e = p;
                        p = p.Kovetkezo;
                    }
                    if (p == null)
                    {
                        uj.Kovetkezo = null;
                        e.Kovetkezo = uj;
                    }
                    else
                    {
                        uj.Kovetkezo = p;
                        e.Kovetkezo = uj;
                    }
                }
            }
        }
        public void Bejaras()
        {
            ListaElem p = fej;

            while (p != null)
            {
                //Console.WriteLine(p.szuperhos.Ero);
                Console.WriteLine($"" +
                    $"Név: {p.szuperhos.Nev}, " +
                    $"mutáns?: {p.szuperhos.Mutans}, " +
                    $"erő: {p.szuperhos.Ero}, " +
                    $"gyors: {p.szuperhos.Gyorsasag}");
                //_metodus?.Invoke(p.szuperhos.Ero);
                p = p.Kovetkezo;
            }
        }
        public void Kereses(string nev)
        {
            ListaElem p = fej;

            while ((p != null) && (p.szuperhos.Nev != nev))
            {
                p = p.Kovetkezo;
            }
            bool van = (p != null) && (p.szuperhos.Nev == nev) ? true : false;
            if (van)
            {
                Console.WriteLine($"Van ilyen a listában, hogy {nev}");
            }
            else
            {
                throw new NincsIlyenElemException();
            }
        }
        public void Torles(Szuperhos szuperhos)
        {
            ListaElem p = fej;
            ListaElem e = null;
            while ((p != null) && (p.szuperhos != szuperhos))
            {
                e = p;
                p = p.Kovetkezo;
            }
            if (p != null)
            {
                if (e != null)
                {
                    fej = p.Kovetkezo;
                }
                else
                {
                    e.Kovetkezo = p.Kovetkezo;
                    Console.WriteLine($"{szuperhos.Nev} törölve");
                }
            }
            else
            {
                throw new NemtudTorolni();
            }
        }
        public void Torles(int ero)
        {
            ListaElem p = fej;
            ListaElem e = null;
            while ((p != null) && (p.szuperhos.Ero != ero))
            {
                e = p;
                p = p.Kovetkezo;
            }
            if (p != null)
            {
                if (e != null)
                {
                    fej = p.Kovetkezo;
                }
                else
                {
                    e.Kovetkezo = p.Kovetkezo;
                    Console.WriteLine($"{e.szuperhos.Nev} törölve");
                }
            }
            else
            {
                throw new NemtudTorolni();
            }
        }
        public void Torles(string nev)
        {
            ListaElem p = fej;
            ListaElem e = null;
            while ((p != null) && (p.szuperhos.Nev != nev))
            {
                e = p;
                p = p.Kovetkezo;
            }
            if (p != null)
            {
                if (e != null)
                {
                    fej = p.Kovetkezo;
                }
                else
                {
                    e.Kovetkezo = p.Kovetkezo;
                    Console.WriteLine($"{nev} törölve");
                }
            }
            else
            {
                throw new NemtudTorolni();
            }
        }
        public LancoltLista Szures(int ero)
        {
            LancoltLista szurtLista = new LancoltLista();

            ListaElem p = fej;
            while (p != null)
            {
                if (p.szuperhos.Ero == ero)
                {
                    szurtLista.ElemBeszuras(p.szuperhos);
                }
                p = p.Kovetkezo;
            }

            return szurtLista;
        }
        public LancoltLista Szures(string nev)
        {
            LancoltLista szurtLista = new LancoltLista();

            ListaElem p = fej;
            while (p != null)
            {
                if (p.szuperhos.Nev == nev)
                {
                    szurtLista.ElemBeszuras(p.szuperhos);
                }
                p = p.Kovetkezo;
            }

            return szurtLista;

        }
        public LancoltLista Szures(bool mutans)
        {
            LancoltLista szurtLista = new LancoltLista();

            ListaElem p = fej;
            while (p != null)
            {
                if (p.szuperhos.Mutans == mutans)
                {
                    szurtLista.ElemBeszuras(p.szuperhos);
                }
                p = p.Kovetkezo;
            }

            return szurtLista;
        }

        public LancoltLista Unio(LancoltLista masodik)
        {
            LancoltLista unio = new LancoltLista();
            ListaElem p = fej;
            ListaElem p2 = masodik.fej;
            while (p != null)
            {
                unio.ElemBeszuras(p.szuperhos);
                p = p.Kovetkezo;
            }
            while (p2 != null)
            {
                unio.ElemBeszuras(p2.szuperhos);
                p2 = p2.Kovetkezo;
            }

            return unio;
        }
        public LancoltLista Metszet(LancoltLista masodik)
        {
            LancoltLista metszet = new LancoltLista();

            ListaElem p = fej;
            ListaElem p2 = masodik.fej;
            while (p != null)
            {
                while ((p2 != null) && (!p.szuperhos.Equals(p2.szuperhos)))
                {
                    p2 = p2.Kovetkezo;
                }
                if (p2 != null)
                {
                    metszet.ElemBeszuras(p2.szuperhos);

                }
                p = p.Kovetkezo;
                p2 = masodik.fej;
            }

            return metszet;
        }
        public LancoltLista Kulonbseg(LancoltLista amibolKivonunk)
        {
            LancoltLista kulonbseg = new LancoltLista();

            ListaElem p = fej;
            ListaElem p2 = amibolKivonunk.fej;
            while (p != null)
            {
                if (p2 != null && (p.szuperhos.Ero > p2.szuperhos.Ero))
                {
                    while (p2 != null && !(p.szuperhos.Equals(p2.szuperhos)))
                    {
                        p2 = p2.Kovetkezo;
                    }
                    if (p2 == null)
                    {
                        kulonbseg.ElemBeszuras(p.szuperhos);
                    }
                    p2 = amibolKivonunk.fej;
                }

                p = p.Kovetkezo;

            }
            return kulonbseg;

        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiBinaris
{
    class BinaryExpressionTree
    {
        public enum Operator
        {
            Add = 43,
            Sub = 45,
            Mul = 42,
            Div = 47,
            Pow = 94
        }
        Node Root { get; }
        private BinaryExpressionTree(Node root)
        {
            Root = root;
        }
        public static BinaryExpressionTree Build(string expression)
        {
            char[] tomb = expression.ToCharArray();
            for (int i = 0; i < tomb.Length; i++)
            {
                if (!char.IsDigit(tomb[i]) && (int)tomb[i] != (int)Operator.Add
                    && (int)tomb[i] != (int)Operator.Sub
                    && (int)tomb[i] != (int)Operator.Div
                    && (int)tomb[i] != (int)Operator.Mul
                    && (int)tomb[i] != (int)Operator.Pow)
                {
                    throw new InvalidExpressionException(expression, i);
                }
            }
            return Build(tomb);

        }

        public static BinaryExpressionTree Build(char[] tomb)
        {
            Stack<Node> verem = new Stack<Node>();
            for (int i = 0; i < tomb.Length; i++)
            {
                if (char.IsNumber(tomb[i]))
                {
                    verem.Push(new OperandNode(tomb[i]));
                }
                else
                {
                    Node jobb = verem.Pop();
                    Node bal = verem.Pop();
                    verem.Push(new OperatorNode(tomb[i],bal, jobb));
                }
            }
            return new BinaryExpressionTree(verem.Pop());
        }
        public override string ToString()
        {
            if (Root != null)
            {
                return null;
            }
            else
            {
                return ToString(Root);
            }
        }
        private string ToString(Node root)
        {
            if (root.right == null && root.left == null)
            {
                return root.data.ToString();
            }
            return ToString(root.left) + ToString(root.right) + root.data.ToString();
        }
        public string Convert()
        {
            if (Root == null)
            {
                return "";
            }
            else
            {
                return Convert(Root);
            }
        }

        private string Convert(Node root)
        {
            string tmp = "";
            if (root is OperatorNode)
            {
                tmp += $"({Convert(root.left)} {root.data} {Convert(root.right)})";
                return tmp;
            }
            tmp += root.data;
            return tmp;
        }
        public double Evaluate()
        {
            if (Root == null)
            {
                return 0;
            }
            else
            {
                return Evaluate(Root);
            }
        }

        private double Evaluate(Node root)
        {
            if (root == null)
            {
                return 0;
            }
            if (root is OperandNode)
            {
                return double.Parse($"{root.data}", System.Globalization.NumberStyles.Any);
            }
            double left = Evaluate(root.left);
            double right = Evaluate(root.right);

            switch ((root as OperatorNode).optor)
            {
                case Operator.Add:
                        return double.Parse($"{left + right}");
                case Operator.Sub:
                        return double.Parse($"{left - right}");
                case Operator.Mul:
                        return double.Parse($"{left * right}");
                case Operator.Div:
                        return double.Parse($"{left / right}");
                default:
                    return double.Parse($"{Math.Pow(left, right)}");
            }
            
        }

        abstract class Node
        {
            private char Data { get; }
            public char data { get { return Data; } }
            private Node Left { get; }
            public Node left { get { return Left; } }
            private Node Right { get; }
            public Node right { get { return Right; } }
            public Node(char data,Node left,Node right)
            {
                Data = data;
                Left = left;
                Right = right;
            }
            public Node(char data)
            {
                Data = data;
                Right = null;
                Left = null;
            }

        }
        class OperandNode : Node
        {
            public OperandNode(char parameter) : base(parameter)
            {

            }
        }
        class OperatorNode : Node
        {
            Operator Operator { get; }
            public Operator optor { get { return Operator; } }
            public OperatorNode(char data, Node left, Node right) : base(data,left,right)
            {
                switch (data)
                {
                    case '+':
                        {
                            Operator = Operator.Add;
                            break;
                        }
                    case '-':
                        {
                            Operator = Operator.Sub;
                            break;
                        }
                    case '*':
                        {
                            Operator = Operator.Mul;
                            break;
                        }
                    case '/':
                        {
                            Operator = Operator.Div;
                            break;
                        }
                    default:
                        {
                            Operator = Operator.Pow;
                            break;
                        }
                }
            }

        }

    }
}

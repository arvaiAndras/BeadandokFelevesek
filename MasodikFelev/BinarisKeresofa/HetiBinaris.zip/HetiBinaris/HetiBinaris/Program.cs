﻿using System;

namespace HetiBinaris
{
    class Program
    {
        static void Main(string[] args)
        {
            BinaryExpressionTree szam = BinaryExpressionTree.Build("7");
            Console.WriteLine($"Egy számos teszt, a  '{nameof(szam)}' számmal");
            Console.WriteLine($"{szam.ToString()}\t\t = {szam.Convert()}\t\t = {szam.Evaluate()}");
            BinaryExpressionTree egyszeru = BinaryExpressionTree.Build("28+");
            Console.WriteLine($"\nOperátorok '{nameof(egyszeru)}' tesztelése");
            Console.WriteLine($"{egyszeru.ToString()}\t\t = {egyszeru.Convert()}\t\t = {egyszeru.Evaluate()}");
            egyszeru = BinaryExpressionTree.Build("28-");
            Console.WriteLine($"{egyszeru.ToString()}\t\t = {egyszeru.Convert()}\t\t = {egyszeru.Evaluate()}");
            egyszeru = BinaryExpressionTree.Build("28*");
            Console.WriteLine($"{egyszeru.ToString()}\t\t = {egyszeru.Convert()}\t\t = {egyszeru.Evaluate()}");
            egyszeru = BinaryExpressionTree.Build("28/");
            Console.WriteLine($"{egyszeru.ToString()}\t\t = {egyszeru.Convert()}\t\t = {egyszeru.Evaluate()}");
            egyszeru = BinaryExpressionTree.Build("28^");
            Console.WriteLine($"{egyszeru.ToString()}\t\t = {egyszeru.Convert()}\t\t = {egyszeru.Evaluate()}");
            BinaryExpressionTree osszetett = BinaryExpressionTree.Build("234*+");
            Console.WriteLine($"\nOperátorok '{nameof(osszetett)}' Tesztelése");
            Console.WriteLine($"{osszetett.ToString()}\t\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            osszetett = BinaryExpressionTree.Build("23*4+");
            Console.WriteLine($"{osszetett.ToString()}\t\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            osszetett = BinaryExpressionTree.Build("23*45*+");
            Console.WriteLine($"{osszetett.ToString()}\t\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            osszetett = BinaryExpressionTree.Build("23+45-/");
            Console.WriteLine($"{osszetett.ToString()}\t\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            osszetett = BinaryExpressionTree.Build("23+4*5+67^8+/");
            Console.WriteLine($"{osszetett.ToString()}\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            Console.WriteLine();
            try
            {
                osszetett = BinaryExpressionTree.Build("12-3-A-45");
                Console.WriteLine($"{osszetett.ToString()}\t = {osszetett.Convert()}\t\t = {osszetett.Evaluate()}");
            }
            catch (InvalidExpressionException e)
            {
                Console.WriteLine(e.ToString());
            }

        }
    }
}

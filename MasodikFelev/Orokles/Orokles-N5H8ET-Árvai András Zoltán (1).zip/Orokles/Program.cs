﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orokles
{
    class Program
    {
        static void Teszt1()
        {

            Terkep terkep = new Terkep(80, 25);
            TerkepRajzolo rajzolo = new TerkepRajzolo(terkep);
            TerkepEsJarmuRajzolo tejr = new TerkepEsJarmuRajzolo(terkep, 4);

            Jarmu tesztJarmu = new Jarmu('*', 10, 10, terkep);
            Helikopter helikopter = new Helikopter(20, 20, terkep);
            Auto auto = new Auto(30, 23, terkep);
            Tank tank = new Tank(37, 17, terkep,100);
            Szimulacio szimulacio = new Szimulacio(terkep, 4);

            szimulacio.JarmuFelvetel(tesztJarmu);
            szimulacio.JarmuFelvetel(helikopter);
            szimulacio.JarmuFelvetel(auto);
            szimulacio.JarmuFelvetel(tank);

            (helikopter as MozgoJarmu).UjIranyVektor(1, 0);
            (auto as MozgoJarmu).UjIranyVektor(1, 0);
            (tank as MozgoJarmu).UjIranyVektor(1, 0);


            rajzolo.Kirajzol();
            szimulacio.Fut();
        }

        static void Main(string[] args)
        {
            Teszt1();
        }
    }
}

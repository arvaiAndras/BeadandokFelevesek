﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orokles
{
    class Jarmu
    {
        private char azonosito;
        protected float x;
        protected float y;
        protected Terkep terkep;
        public char Azonosito { get { return azonosito; } }
        public float X { get { return x; } }
        public float Y { get { return y; } }
        public Jarmu(char azon, float x, float y, Terkep terkep)
        {
            azonosito = azon;
            this.x = x;
            this.y = y;
            this.terkep = terkep;
        }

        public virtual bool IdeLephet(float x, float y)
        {
            if (terkep.MeretX > x && terkep.MeretY > y && x >= 0 && y >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    abstract class MozgoJarmu : Jarmu
    {
        protected float iranyX, iranyY;
        public void UjIranyVektor(float iranyX,float iranyY)
        {
            this.iranyX = iranyX;
            this.iranyY = iranyY;
        }
        public MozgoJarmu(char azon, float x, float y, Terkep terkep) : base(azon,x,y, terkep)
        {

        }

        public abstract void Mozog();
    }
    class Helikopter : MozgoJarmu
    {
        private float sebesseg = 1;
        protected void Gyorsit()
        {
            sebesseg += (float)0.1;
        }
        protected void Lassit()
        {
            if (sebesseg >= 0.1)
            {
                sebesseg -= (float)0.1;
            }
        }
        public override void Mozog()
        {
            if (IdeLephet(X + this.iranyX * sebesseg,Y + this.iranyY * sebesseg).Equals(true))
            {
                x = (float)Math.Round((x + this.iranyX * sebesseg), 0);
                y = (float)Math.Round((y + this.iranyY * sebesseg), 0);
            }
        }
        public Helikopter(float x, float y, Terkep terkep): base('H',x,y,terkep)
        {

        }
    }
    class Auto : MozgoJarmu
    {
        private float sebesseg = 1;
        public override bool IdeLephet(float x, float y)
        {
            if (terkep.Magassag(x,y) > 0 && base.IdeLephet(x,y))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override void Mozog()
        {
            if (IdeLephet(X + this.iranyX * sebesseg, Y + this.iranyY * sebesseg).Equals(true))
            {
                float magKulonb = terkep.Magassag(x, y) - terkep.Magassag(x + this.iranyX * sebesseg, y + this.iranyY * sebesseg);
                if (magKulonb > 0)
                {
                    sebesseg += (float)1.1;
                }
                else if(magKulonb < 0)
                {
                    sebesseg -= (float)1.1;
                }
            }
            x = (float)Math.Round((x + this.iranyX * sebesseg), 0);
            y = (float)Math.Round((y + this.iranyY * sebesseg), 0);
        }
        public Auto(int x, int y, Terkep terkep, char azon = 'A') : base(azon,x,y,terkep)
        {
            
        }
    }
    sealed class Tank : Auto
    {
        private float sebesseg = 1;
        float uzemanyag;
        public float Uzemanyag { get { return uzemanyag; } }
        public override bool IdeLephet(float x, float y)
        {
            if (terkep.MeretX > x && terkep.MeretY > y)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Tank(int x, int y, Terkep terkep,float uzemanyag) : base(x, y, terkep,'T')
        {
            this.uzemanyag = uzemanyag;
        }
        public override void Mozog()
        {
            if (uzemanyag >= 10 && IdeLephet(x + iranyX ,y + iranyY).Equals(true))
            {
                x += iranyX;
                y += iranyY;
                uzemanyag -= 10;
            }
        }
    }
}

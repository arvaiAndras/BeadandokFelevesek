﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiGraf
{
    class Program
    {
        
        static void Edge(object source, Graph<string>.GraphEventArgs<string> geargs)
        {
            Console.WriteLine($"New Edge: {geargs.from.ToString()} ---> {geargs.to.ToString()}");
        }
        static void OutPut(string data)
        {
            Console.WriteLine(data);
        }
        static void Main(string[] args)
        {
            Graph<string> myGraph = new Graph<string>();
            myGraph.myEvent += Edge;

            myGraph.AddNode("Stew");
            myGraph.AddNode("Marge");
            myGraph.AddNode("Joseph");
            myGraph.AddNode("Gerald");
            myGraph.AddNode("Zack");
            myGraph.AddNode("Peter");
            myGraph.AddNode("Janet");

            myGraph.AddEdge("Stew", "Joseph");
            myGraph.AddEdge("Stew", "Marge");
            myGraph.AddEdge("Marge", "Joseph");
            myGraph.AddEdge("Joseph", "Gerald");
            myGraph.AddEdge("Joseph", "Zack");
            myGraph.AddEdge("Gerald", "Zack");
            myGraph.AddEdge("Zack", "Peter");
            myGraph.AddEdge("Peter", "Janet");

            Console.WriteLine("\nBFS:\n");
            myGraph.BFS("Joseph", OutPut);
            Console.WriteLine("DFS: \n");
            myGraph.DFS("Joseph", OutPut);

            string vane = myGraph.HasEdge("Stew", "Zack") ? "Van" : "Nincs";
            string vane2 = myGraph.HasEdge("Peter", "Janet") ? "Van" : "Nincs";
            Console.WriteLine("\n" + vane);
            Console.WriteLine(vane2);
            ;
            Console.ReadLine();
        }
    }
}

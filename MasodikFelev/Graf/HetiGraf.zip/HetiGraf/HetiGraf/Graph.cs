﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetiGraf
{
    class Graph<T>
    {
        public delegate void ExternalProcessor(string item);
        public delegate void GraphEventHandler<T>(object source, GraphEventArgs<T> geargs);
        public event GraphEventHandler<T> myEvent;
        public class GraphEventArgs<T>
        {
            public T from;
            public T to;
            public GraphEventArgs(T from, T to)
            {
                this.from = from;
                this.to = to;
            }
        }
        List<T> datas = new List<T>();
        List<List<T>> neighbors = new List<List<T>>();
        public void AddNode(T node)
        {
            datas.Add(node);
            neighbors.Add(new List<T>());
        }
        public void AddEdge(T from, T to)
        {
            int indexFrom = datas.IndexOf(from);
            int indexTo = datas.IndexOf(to);
            GraphEventArgs<T> handler = new GraphEventArgs<T>(from, to);
            myEvent?.Invoke(this, handler);
            neighbors[indexFrom].Add(datas[indexTo]);
            neighbors[indexTo].Add(datas[indexFrom]);
        }
        public bool HasEdge(T from, T to)
        {
            int indexFrom = datas.IndexOf(from);
            int indexTo = datas.IndexOf(to);
            return neighbors[indexFrom].Contains(datas[indexTo]);
        }
        List<T> Neighbors(T node)
        {
            int idx = datas.IndexOf(node);
            return neighbors[idx];
        }
        public void BFS(T from,ExternalProcessor item)
        {
            Queue<T> S = new Queue<T>();
            List<T> F = new List<T>();
            int[] D = new int[datas.Count];

            int index = datas.IndexOf(from);
            D[index] = 0;

            S.Enqueue(from);
            F.Add(from);
            T k;

            while (S.Count != 0)
            {
                k = S.Dequeue();
                item?.Invoke(k as string);
                foreach (T x in Neighbors(k))
                {
                    if (!F.Contains(x))
                    {
                        S.Enqueue(x);
                        F.Add(x);
                        D[datas.IndexOf(x)] = D[datas.IndexOf(k)] + 1;
                    }
                }
            }
            for (int i = 0; i < D.Length; i++)
            {
                item?.Invoke(D[i].ToString());
            }
        }
        public void DFS(T from,ExternalProcessor item)
        {
            List<T> F = new List<T>();
            DFSRec(from, ref F, item);
        }
        public void DFSRec(T k, ref List<T> F,ExternalProcessor item)
        {
            F.Add(k);
            item?.Invoke(k as string);
            foreach (T x in Neighbors(k))
            {
                if (!F.Contains(x))
                {
                    DFSRec(x, ref F,item);
                }
            }
        }
    }
}
